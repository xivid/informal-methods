input="1 2
3 4
5 6"
echo "$input" | while read n1 n2
do
    echo "$n1" vs "$n2"
done 
